@extends('inc.ai_layout')
@Section('content')
<body>
    <div style="">
        <div class=""></div>
        <div class="">
            <div class="row login_row_cont">
                <div class="col-md-3 ">                                    
                </div>
                <div class="col-md-6 bg_white mt-5">
                    
                    <div class="row">
                        <div class="col-md-12" >
                            <div class="">
                                <div align="center">
                                    <br>
                                    <h2 class="text-primary">
                                        MaxProfit Licence Activation
                                    </h2>
                                    <h4 class="colhd mt-2">{{ __('messages.activation_title') }}</h4>
                                    <h4 class="colhd mt-2">{{ __('messages.activation_summ') }}</h4>
                                    <!-- <hr> -->
                                </div>
                            </div>

                            <div class="container">
                                <form method="POST" action="{{ route('login_system') }}" class=""> 
                                    @if(Session::has('err'))
                                        <div class="alert alert-danger">
                                            {{Session::get('err')}}
                                        </div>
                                        {{Session::forget('err')}}
                                    @endif                                 
                                                                                
                                    <div class="form-group row" >
                                        <div class="col-md-12">
                                            <label class="mt-2"> 
                                                <b>{{ __('messages.actvation_key') }}</b>
                                            </label>
                                            <br>
                                            <input type="text" class="regTxtBox " name="key" value="" required placeholder="{{ __('messages.actvation_key') }}">
                                            <br>
                                            <!--<input type="text" class="regTxtBox activation_txtBox" name="envato_user" value="" required placeholder="{{ __('messages.evato_username') }}">-->
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row mt-3">
                                        <div class="col-md-6">
                                            <label class="">
                                                <b>{{ __('Admin email') }}</b>
                                            </label>
                                            <br>
                                            <input type="email" class="regTxtBox " name="username" value="" required placeholder="{{ __('messages.admin_email') }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="">
                                                <b>{{ __('Admin Password') }}</b>
                                            </label>
                                            <br>
                                            <input type="password" class="regTxtBox " name="password" value="" required placeholder="{{ __('messages.admin_form_pwd') }}">  
                                            @if($errors->has('password'))
                                                <br>  
                                                <span class="text-danger">{{ $errors->first('password') }}</span> 
                                            @endif
                                        </div>
                                    </div>
                                   
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <label class="mt-3">
                                                {{ __('messages.database_settings') }}
                                            </label>                   
                                            <br>        
                                            <input type="text" class="regTxtBox " name="db_user" value="" required  placeholder="Database User E.g 'root'">
                                            @if($errors->has('db_user'))
                                                <br>  
                                                <span class="text-danger">{{ $errors->first('db_user') }}</span> 
                                            @endif
                                            <br>              
                                            <input type="password" class="regTxtBox activation_txtBox" name="db_pwd" value="" placeholder="Database password">
                                            <br>
                                            <input type="text" class="regTxtBox activation_txtBox" name="db_name" value="" required placeholder="Database Name">
                                            @if($errors->has('db_name'))
                                                <br>  
                                                <span class="text-danger">{{ $errors->first('db_name') }}</span> 
                                            @endif
                                        </div>

                                        <div class="col-md-6">
                                            <label class="mt-3">
                                                {{ __('messages.site_settings') }}
                                            </label>
                                        
                                            <input type="text" class="regTxtBox " name="site_name" value="" required placeholder="{{ __('messages.site_name') }}">
                                       
                                            <input type="text" class="regTxtBox activation_txtBox" name="site_descr" value="" required placeholder="{{ __('messages.site_description') }}">
                                        </div>
                                    </div>
                                   
                                    <div class="form-group row">
                                        
                                    </div>

                                    <div class="mb-5">
                                        <div class="mt-5" align="center">
                                            <button type="submit" class="collc btn btn-primary">
                                                {{ __('messages.btn_activate') }}
                                            </button>                               
                                        </div>                                                
                                    </div>
                                </form>
                            </div>
                                
                        </div>
                    </div>
                    
                </div>
            </div>
            <br><br>
        </div>
    </div>
   
@endSection
