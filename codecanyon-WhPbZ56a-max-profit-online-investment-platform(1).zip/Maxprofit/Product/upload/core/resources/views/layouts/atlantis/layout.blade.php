<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>{{$settings->site_title}} - {{$settings->site_descr}}</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="/img/{{$settings->favicon}}" type="image/x-icon"/>
	<!-- Fonts and icons -->
	<link href="/atlantis/fontawesome6/css/all.css" rel="stylesheet">
	<link href="/atlantis/fontawesome6/css/brands.css" rel="stylesheet">
	<link href="/atlantis/fontawesome6/css/solid.css" rel="stylesheet">
	<link rel="stylesheet" href="/atlantis/css/fonts.min.css">
	<!--  -->
	<!-- CSS Files -->
	<link rel="stylesheet" href="/atlantis/css/bootstrap.min.css">
	<link rel="stylesheet" href="/atlantis/css/atlantis.min.css">
	<link rel="stylesheet" href="/atlantis/style.css">

	
	<!-- jquery lib -->
	<script src="/atlantis/js/core/jquery.3.2.1.min.js"></script>

</head>

<body>

@include('layouts.atlantis.header')
@yield('content')
@include('layouts.atlantis.footer')



</body>

</html>