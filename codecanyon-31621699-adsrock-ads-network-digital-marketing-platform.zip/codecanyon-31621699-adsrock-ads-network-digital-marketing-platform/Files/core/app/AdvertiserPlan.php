<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdvertiserPlan extends Model
{
    protected $guarded = [];
}
