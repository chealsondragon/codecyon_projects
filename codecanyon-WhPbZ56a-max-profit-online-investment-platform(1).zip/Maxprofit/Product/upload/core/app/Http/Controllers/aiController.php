<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Route;

use App\states;
use App\country;
use Session;
use Hash;
use File;
use Auth;
use App\User;
use App\banks;
use App\activities;
use App\packages;
use App\investment;
use App\msg;
use App\admin;
use App\deposits;
use App\withdrawal;
use App\adminLog;
use App\xpack_inv;
use Validator;
use App\site_settings;
use Paystack;

use GuzzleHttp\Client as GuzzleClient;
use DotenvEditor;

class aiController extends Controller
{

  public function login_system(Request $req)
  { 

    Validator::extend('without_spaces', function($attr, $value){
        return preg_match('/^\S*$/u', $value);
    });
      
    $req->validate(
      [
        'password' => 'min:6',
        'db_user' => 'required|without_spaces',
        'db_name' => 'required|without_spaces'
      ],
      [

        'db_user.without_spaces' => __('messages.white_space_db_usr'),
        'db_name.without_spaces' => __('messages.white_space_db_name')
      ]
    );

    try
    {
      $domain = request()->getHost();
      $url = 'https://demo.mcode.me/coinpayment/confirm/a';          
      $ch = curl_init($url);          
      $data = array(
        'key' => $req['key'],
        'url' => $domain
      );
      $payload = json_encode($data);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
      curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($ch);
      curl_close($ch);
      
      $response = json_decode($result);

      if(isset($response->resp) && $response->resp == 'ok')
      { 
        
        $pwdd = Hash::make($req['password']);
        $res=load_db_tables($req['db_user'], $req['db_pwd'], $req['db_name'], $req['username'], $pwdd, $req['site_name'], $req['site_descr']); 
        
        if($res != 'suc') 
        {
          return back()->with(['err' => $res]);
        }       
        $file = DotenvEditor::setKeys([
            [
              'key'     => 'VARIABLE_KEY',
              'value'   => $req['key']
            ], 
            [
              'key'     => 'APP_NAME',
              'value'   => $req['site_name']
            ],
            [
              'key'     => 'APP_DESCR',
              'value'   => $req['site_descr']
            ],
            [
              'key'     => 'APP_URL',
              'value'   => $domain
            ],
            [
              'key'     => 'DB_DATABASE',
              'value'   => $req['db_name']
            ],
            [
              'key'     => 'DB_USERNAME',
              'value'   => $req['db_user']
            ],
            [
              'key'     => 'DB_PASSWORD',
              'value'   => $req['db_pwd']
            ]
          
        ]);

        $file->save();
        DotenvEditor::deleteBackups();
        $file_cont = json_encode($data);
        \Storage::put('file.txt', $file_cont);
        return redirect()->route('mail_settings');
      } 
      
      if(isset($response->resp) && $response->resp == 'diff_domain')
      {
        return back()->with(['err' => __('messages.key_u_dif_d')]);
      }

      if(isset($response->resp) && $response->resp == 'not_found')
      {
        return back()->with(['err' => __('messages.act_key_nt_fnd')]);
      }
      
      return back()->with(['err' => __('messages.check_act_key')]); 
    }
    catch(\Exception $e)
    {
      return back()->with(['err' => __('messages.act_err_key2' . $e->getMessage())]); 
    }
    
  }

  public function mail_settings()
  {
    return view('auth.smtp');
  }

  public function mail_settings_save(Request $req)
  {
    
    $file = DotenvEditor::setKeys([
      [
          'key'     => 'MAIL_DRIVER',
          'value'   => $req['mail_driver']
      ],              
      [
          'key'     => 'MAIL_HOST',
          'value'   => $req['mail_host']
      ],
      [
          'key'     => 'MAIL_PORT',
          'value'   => $req['mail_port']
      ],
      [
          'key'     => 'MAIL_USERNAME',
          'value'   => $req['mail_user']
      ],
      [
          'key'     => 'MAIL_PASSWORD',
          'value'   => $req['mail_password']
      ],
      [
          'key'     => 'MAIL_ENCRYPTION',
          'value'   => $req['mail_encrypt']
      ]
      
    ]);
    $file = DotenvEditor::save();

    return redirect('/admin');
  }

}