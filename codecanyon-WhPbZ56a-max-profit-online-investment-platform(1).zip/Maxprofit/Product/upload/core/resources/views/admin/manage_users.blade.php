@extends('admin.atlantis.layout')
@Section('content')
    <div class="main-panel">
        <div class="content">
            @php($page_title = __('messages.manage_usr'))
            @include('admin.atlantis.main_bar')
            <div class="page-inner mt--5">
               
                <div id="prnt"></div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card ">
                            <div class="card-header">
                                <div class="card-head-row card-tools-still-right">
                                    <h5 class="text-primary" > {{ __('messages.all_usrs') }} </h5>
                                    <div class="card-tools">
                                       <form action="/admin/search/user" method="post">
                                            <div class="form-group d-flex flex-row justify-content-center align-items-center">
                                                <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                <input type="text" name="search_val" class="form-control border_radius_15px" placeholder=" {{ __('messages.search_by') }} ">
                                                <i class="fa fa-search ml--5 search_btn_on_input"></i>
                                            </div>
                                        </form>
                                    </div>                                                                             
                                </div>
                                @php($users_table = search_users())                               
                                <!-- <p class="card-category text-white" > {{ __('messages.all_regstrd_usrs') }} </p> -->
                            </div>
                            <div class="card-body scrollable_div">
                                @if(count($users_table) > 0 )
                                    @foreach($users_table as $user)
                                        <table class="new_table table-stripped table-hover">                                            
                                            <tbody>                                                
                                                <tr>
                                                    <td width="10px">
                                                        @if($user->status == 1 || $user->status == 'Active')
                                                            <i class="fa-solid fa-user fa-2x text-success"></i>
                                                        @elseif($user->status == 2 || $user->status == 'Not Active')
                                                            <i class="fa-solid fa-user fa-2x text-danger"></i>
                                                        @else
                                                            <i class="fa-solid fa-user fa-2x text-black"></i>
                                                        @endif
                                                    </td>
                                                    <td class="text-nowrap">
                                                        {{$user->firstname}} {{$user->lastname}}
                                                    </td>
                                                    <td>
                                                        {{$user->email}} &nbsp; {{$user->phone}}</td> 
                                                    </td>
                                                    <td>
                                                        <a class="btn btn-info" href="/admin/view/userdetails/{{$user->id}}" title="{{ __('messages.v_usr_det') }}">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                    </td>          
                                                </tr>
                                            </tbody>
                                        </table>
                                    @endforeach
                                @else
                                    
                                @endif         
                                <div class="" align="">
                                   <span> {{$users_table->links()}}</span>  
                                </div>
                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endSection