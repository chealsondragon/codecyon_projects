<?php
	$settings = App\site_settings::find(1);
?>

<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>{{$settings->site_title}} - {{$settings->site_descr}}</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon"  href="/img/{{$settings->favicon}}" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<link href="/atlantis/fontawesome6/css/all.css" rel="stylesheet">
	<link href="/atlantis/fontawesome6/css/brands.css" rel="stylesheet">
	<link href="/atlantis/fontawesome6/css/solid.css" rel="stylesheet">
	<link rel="stylesheet" href="/atlantis/css/fonts.min.css">

	<!-- CSS Files -->
	<link rel="stylesheet" href="/atlantis/css/bootstrap.min.css">
	<link rel="stylesheet" href="/atlantis/css/atlantis.min.css">
	<link rel="stylesheet" href="/atlantis/style.css">
	<!--   Core JS Files   -->
	<script src="/atlantis/js/core/jquery.3.2.1.min.js"></script>
	<script src="/atlantis/js/core/popper.min.js"></script>
	<script src="/atlantis/js/core/bootstrap.min.js"></script>

	<!-- jQuery UI -->
	<script src="/atlantis/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script  src="/atlantis/jquery-ui-1.13.1/jquery-ui.min.js"></script>
	<script src="/atlantis/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="/atlantis/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


	<!-- Chart JS -->
	<script src="/atlantis/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="/atlantis/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="/atlantis/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="/atlantis/js/plugin/datatables/datatables.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="/atlantis/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="/atlantis/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="/atlantis/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Sweet Alert -->
	<script src="/atlantis/js/plugin/sweetalert/sweetalert.min.js"></script>

	<!-- Atlantis JS -->
	<script src="/atlantis/js/atlantis.min.js"></script>

	<!-- <script src="/atlantis/main.js"></script> -->
	<script src="/atlantis/js/moment.js"></script>

	 <!-- tinymce -->
    <script src="/tinymce5/jquery.tinymce.min.js"></script>
    <script src="/tinymce5/tinymce.min.js"></script>
    <!-- tinymce -->
    
</head>

<body>
	<div class="wrapper">
		<div class="main-header box_shadow">
			<!-- Logo Header -->
			<div class="logo-header " style="background-color: #121F3E;" align="center">
				<a id="dash_logo" href="/admin/home" class="text-white text-uppercase xbold font_wgh_900">
                    {{$settings->site_title}}                   
                </a>
				<button id="mlogo_toggle" class="navbar-toggler sidenav-toggler ml-auto text-primary" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
					&nbsp;
					    <i class="fa fa-circle-dot text-white" style="font-size:22px"></i>
				</button>				 
				<button class="topbar-toggler more text-primary">
					<i class="fas fa-ellipsis-vertical text-white"></i>
				</button>
				<div class="nav-toggle ">
			   <i id="dsh_toggle" class="fa fa-circle-dot text-white btn toggle-sidebar ml_30px" style="font-size:22px"></i>
			</div>
			</div>
			<script>
                $('#dsh_toggle').on('click', function(){
                    $('#dash_logo').toggle();
                    if($('#dash_logo').is(':visible'))
                    {
                        $('#dsh_toggle').addClass('ml_30px');
                    }
                    else
                    {
                        $('#dsh_toggle').removeClass('ml_30px');
                    }
                });
            </script>
            <script>
                var tg = 0;
                $('#mlogo_toggle').on('click', function(){
                    // $('#dash_logo').toggle();
                    if(tg == 0)
                    {
                        $('#dash_logo').hide();
                        tg = 1;
                    }
                    else
                    {
                        $('#dash_logo').show();
                        tg = 0;
                    }
                });
            </script>
			<!-- End Logo Header -->

			<!-- Navbar Header -->
			<nav class="navbar navbar-header navbar-expand-lg" style="background-color: #fff;">
				<div class="container-fluid">
				    <div class="collapse" id="search-nav">
					    <h4 class="text-primary">@if(isset($page_title)){{ $page_title }}@endif</h4>
					</div>
					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
						<li class="nav-item dropdown hidden-caret">
							<a class="dropdown-toggle text-primary" data-toggle="dropdown" href="#" aria-expanded="false">
								<i class="fa fa-flag"></i> 
								@if(Session::has('locale'))
									{{ strtoupper(Session::get('locale')) }}
								@else
									{{ __('EN') }}
								@endif
								<i class="fa-solid fa-caret-down"></i>
							</a>
							<ul class="dropdown-menu dropdown-adm animated fadeIn">
								<?php
                                    $activities = $lang;
                                ?>
                                @if(count($activities) > 0 )
                                    @foreach($activities as $activity)
                                        <li>
											<a class="dropdown-item" href="{{ url('locale/'.$activity->lang_code) }}">
												<i class="fa fa-flag"></i> &nbsp;{{ $activity->lang_name }}
											</a>
										</li>
                                    @endforeach
                                @else
                                    {{ __('No language') }}
                                @endif																
																
							</ul>
						</li>
						<li class="nav-item dropdown hidden-caret">&emsp;</li>
						<li class="nav-item dropdown hidden-caret">
							&nbsp;&nbsp;
							<a class="dropdown-toggle text-primary" href="{{ route('support.index')}}" >
								<?php                                  
	                                $msgs = App\ticket::With('comments')->orderby('id', 'desc')->get();
	                                $rd = 0;
	                            ?>								
								<i class="fab fa-teamspeak not_cont text-primary">
									@foreach($msgs as $msg) 
                                        @if($msg->state == 1)                        
                                            @php($rd = 1)                                  
                                        @endif
                                        @foreach($msg->comments as $comment)
                                        	@if($comment->state == 1 && $comment->sender == 'user')
                                        		@php($rd = 1)
                                        	@endif
                                        @endforeach                                   
                                    @endforeach
                                    @if($rd == 1)   
                                    	<i class="fa fa-circle new_not "></i>
                                    @endif									
								</i> {{ __('messages.supt_cntr') }}
							</a>							
						</li>
						
						<li class="nav-item dropdown hidden-caret">&emsp;</li>
						<li class="nav-item dropdown hidden-caret">
							&nbsp;
							<a class="dropdown-toggle profile-pic text-primary" data-toggle="dropdown" href="#" aria-expanded="false">
								@if($adm->img == "")
									<i class="fa-solid fa-circle-user"></i>
								@else							
									<img src="/img/{{ $adm->img }}" alt="avatar" class="avatar-img user_avatar_size_20" align="center" />
								@endif	
								{{ $adm->name }}
								<i class="fa-solid fa-caret-down"></i>
							</a>
							<ul class="dropdown-menu dropdown-adm animated fadeIn">
								<div class="dropdown-adm-scroll scrollbar-outer">
									<li>																			
										<a class="dropdown-item" href="/admin/manage/users">
											<i class="fa fa-users"></i> &nbsp;{{ __('messages.manage_usr') }}
										</a>
										@php($role = Session::get('adm'))
                                        @if($role->role == 3)
											<a class="dropdown-item" href="/admin/manage/adminUsers">
												<i class="fa fa-users"></i>&nbsp; {{ __('messages.mgr_adm_usr') }}
											</a>
											<a class="dropdown-item" href="/admin/manage/investments">
												<i class="fa fa-paper-plane"></i>&nbsp; {{ __('messages.mang_invstm') }}
											</a>
											<a class="dropdown-item" href="/admin/manage/deposits">
												<i class="fas fa-donate"></i>&nbsp; {{ __('messages.usr_dpst') }}
											</a>
											<a class="dropdown-item" href="/admin/manage/withdrawals">
												<i class="fa fa-file"></i>&nbsp; {{ __('messages.usr_wthdrwl') }} 
											</a>
										@endif

										<a class="dropdown-item" href="/admin/manage/packages">
											<i class="fa fa-briefcase"></i>&nbsp; {{ __('messages.pkgs') }}
										</a>
										<a class="dropdown-item" href="/admin/send/msg">
											<i class="fa fa-bell"></i>&nbsp; {{ __('messages.snd_notifctn') }}
										</a>
										<a class="dropdown-item" href="/admin/change/pwd">
											<i class="fa fa-key"></i>&nbsp; {{ __('messages.chng_pwd') }}
										</a>	
										<a class="dropdown-item" href="{{route('support.index')}}">
											<i class="fab fa-teamspeak"></i>&nbsp; {{ __('messages.sprt_centr') }}
										</a>	

										@php($role = Session::get('adm'))
                                        @if($role->role == 3)		
                                        	<a class="dropdown-item" href="/admin/viewlogs">
												<i class="fa fa-list"></i>&nbsp; {{ __('messages.vw_usr_actv') }}
											</a>
											<a class="dropdown-item" href="/admin/view/settings">
												<i class="fa fa-gears"></i>&nbsp; {{ __('messages.Sttng') }}
											</a>
										@endif								
										
										
										<a class="dropdown-item" href="/logout"><i class="fa fa-arrow-right"></i> &nbsp;{{ __('messages.logout') }}</a>

									</li>
								</div>
							</ul>
						</li>
					</ul>
				</div>
			</nav>
			<!-- End Navbar -->
		</div>

		<!-- Sidebar -->
		<div class="sidebar sidebar-style-2" style="background-color: #121F3E;">			
			<div class="sidebar-wrapper scrollbar scrollbar-inner">
				<div class="sidebar-content ">					
					<ul class="nav nav-primary all_text_color">
					    <li class="nav-item @if(Request::path() == 'admin/home'){{__('active')}} @endif">
					    	<a class="" href="/admin/home">
								<font class="fas fa-columns fa_1x"></font>
								&emsp;
								<span> {{ __('messages.dasbrd') }}</span>
							</a>
						</li>
						<li class="nav-item  @if(Request::path() == 'admin/profile/settings'){{__('active')}} @endif">
							<a class="" href="/admin/profile/settings">
							    <font class="fa-solid fa-user-pen fa_1x" ></font>&emsp;
								<span class="" >{{ __('messages.prfl') }}</span>
							</a>
						</li>
						@php($role = Session::get('adm'))
                        @if($role->role == 3)
                        	<li class="nav-item ">
								<a data-toggle="collapse" href="#user_drp">
									<font class="fa fa-users fa_1x"></font>&emsp;
									<span> {{ __('messages.manage_usr') }}</span>
									<span class="caret"></span>
								</a>
								<div class="collapse" id="user_drp" >
									<ul class="nav nav-collapse">
										<li class="@if(Request::path() == 'admin/manage/users'){{__('active')}} @endif">
				                        	<a href="/admin/manage/users">
												<span class="sub-item"> {{ __('messages.users') }} </span>
											</a>
										</li>
										
										<li class="@if(Request::path() == 'admin/manage/adminUsers'){{__('active')}} @endif">
											<a href="/admin/manage/adminUsers">
												<span class="sub-item"> {{ __('messages.admn') }} </span>
											</a>
										</li>
									</ul>
								</div>
							</li>
							
							<li class="nav-item @if(Request::path() == 'admin/manage/investments'){{__('active')}} @endif">
						    	<a href="/admin/manage/investments">
									<font class="fas fa-hand-holding-usd fa_1x"></font>&emsp;
									<span>{{ __('messages.mang_invstm') }}</span>
								</a>
							</li>
							
							<li class="nav-item @if(Request::path() == 'admin/manage/deposits'){{__('active')}} @endif">
						    	<a href="/admin/manage/deposits">
									<font class="fas fa-donate fa_1x"></font>&emsp;
									<span> {{ __('messages.usr_dpst') }} </span>
								</a>
							</li>
							
							<li class="nav-item @if(Request::path() == 'admin/manage/withdrawals'){{__('active')}} @endif">
						    	<a href="/admin/manage/withdrawals">
									<font class="fas fa-arrow-circle-down fa_1x"></font>&emsp;
									<span> {{ __('messages.usr_wthdrwl') }} </span>
								</a>
							</li>
						@endif
						
						<li class="nav-item @if(Request::path() == 'admin/manage/packages'){{__('active')}} @endif">
					    	<a href="/admin/manage/packages">
								<font class="fa fa-briefcase fa_1x"></font>&emsp;
								<span> {{ __('messages.pkgs') }} </span>
							</a>
						</li>
						
						<li class="nav-item @if(Request::path() == 'admin/send/msg'){{__('active')}} @endif">
					    	<a href="/admin/send/msg">
								<font class="fa fa-bell fa_1x"></font>&emsp;
								<span> {{ __('messages.snd_notifctn') }}</span>
							</a>
						</li>
						<li class="nav-item @if(Request::path() == 'support'){{__('active')}} @endif">
					    	<a href="{{route('support.index')}}">
								<font class="fab fa-teamspeak fa_1x"></font>&emsp;
								<span> {{ __('messages.sprt_centr') }} </span>
							</a>
						</li>			

												
                        @if($role->role == 3)
							<li class="nav-item ">
								<a data-toggle="collapse" href="#base">
									<font class="fas fa-wrench fa_1x"></font>&emsp;
									<span>{{ __('messages.Sttng') }}</span>
									<span class="caret"></span>
								</a>
								<div class="collapse" id="base">
									<ul class="nav nav-collapse">
										<li class=" @if(Request::path() == 'admin/view/settings'){{__('active')}} @endif">
											<a href="/admin/view/settings">
												<span class="sub-item">{{ __('messages.Sttng') }}</span>
											</a>
										</li>
										<li class="@if(Request::path() == 'admin/manage/deposits'){{__('active')}} @endif">
											<a href="/admin/profile/kyc">
												<span class="sub-item">{{ __('messages.kyc') }}</span>
											</a>
										</li>
										<li class="@if(Request::path() == 'admin/viewlogs'){{__('active')}} @endif">
				                        	<a href="/admin/viewlogs">
												<span class="sub-item">{{ __('messages.vw_usr_actv') }}</span>
											</a>
										</li>
									</ul>
								</div>
							</li>
						@endif	

						
						<li class="nav-item">
							<a href="/logout">
								<font class="fas fa-arrow-left fa_1x"></font>&emsp;
								<span>{{ __('messages.logout') }}</span>
								<!-- <span class="caret"></span> -->
							</a>							
						</li>
						
					</ul>
				</div>
			</div>
		</div>
		<script>
		    $(document).ready(function() {
                // $('.nav-item').on('mouseover', function(e) {
                //     $('.nav-item').css('background-color', '#000066');
                //     $(this).css('color', 'white');
                    // alert('here');
                // });
            });
		</script>
		<!-- End Sidebar -->