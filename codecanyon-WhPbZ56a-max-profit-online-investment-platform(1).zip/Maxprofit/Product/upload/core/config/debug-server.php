<?php

return [
    /*
     * The host to use when listening for debug server connections.
     */
    'host' => 'tcp://127.0.0.1:9912',
];
