<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\states;
use App\country;
use Session;
use Hash;
use File;
use Auth;
use App\User;
use App\banks;
use App\activities;
use App\packages;
use App\investment;
use App\msg;
use App\admin;
use App\deposits;
use App\withdrawal;
use App\adminLog;
use App\xpack_inv;
use Validator;
use App\site_settings;

class guest extends Controller
{
    public function guest_msg(Request $req)
    {
        try{
            // dd('here');
            $maildata =  $req->all();
            Mail::send('mail.contact', ['md' => $req->all()], function($msg) use ($maildata){
                $msg->from($maildata['email']);
                $msg->to(env('SUPPORT_EMAIL'));
                $msg->subject($maildata['subject']);
            });
            
            return back()->with([
                  'toast_msg' => '',
                  'toast_type' => 'suc'
            ]);
            
        }
        catch(\Exception $e)
        {
            return back()->with([
                  'toast_msg' => '',
                  'toast_type' => 'err'
            ]);
        }
    }

}