<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class lang extends Model
{
    protected $table="lang";
}
