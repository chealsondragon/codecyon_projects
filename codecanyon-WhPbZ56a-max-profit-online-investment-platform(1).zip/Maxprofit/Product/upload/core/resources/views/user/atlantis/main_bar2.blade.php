<div class="panel-header bg-white" >
	<div class="page-inner py-5 bg-white" >
		<div class="row">
			<div class="col">
				<h4 class="text-primary">
					{{__('messages.hi')}} {{ $user->firstname }} 
				</h4>
				<p class="text-grey">
					{{ $page_info }} 
				</p>					
				
			</div>			
		</div>
	</div>
</div>